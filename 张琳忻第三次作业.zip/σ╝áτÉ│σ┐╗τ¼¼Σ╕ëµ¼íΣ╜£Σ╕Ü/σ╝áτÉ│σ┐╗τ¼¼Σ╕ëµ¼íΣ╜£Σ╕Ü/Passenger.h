//
//  Passenger.h
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Orders : NSObject
@property (nonatomic, copy) NSNumber *orderNumber;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSNumber *flightNumber;
@property (nonatomic, copy) NSNumber *seatNumber;
@property (nonatomic, copy) NSDate *boardingTime;
@property (nonatomic, copy) CLLocation *departure;
@property (nonatomic, copy) CLLocation *destination;
@property (nonatomic, copy) NSString *detail;
@end

@interface Passenger : Person

// @property 属性
// 是否年满 18 岁
@property (nonatomic, assign, readonly) BOOL *eighteen;
// 历史订单 （数组）
@property (nonatomic, copy)Orders *historicalOrder;
// 未出行订单 （数组）
@property (nonatomic, copy)Orders *unusedOrder;

// Function 方法
// 去订票
- (void)book:(NSString *)name departure:(CLLocation *)departure destination:(CLLocation *)destination;
// 去检票
- (BOOL)check:(Orders *)unusedOrder;
@end

NS_ASSUME_NONNULL_END
