//
//  Passenger.m
//  College Demo
//
//  Created by mashujun on 2022/7/18.
//

#import "Passenger.h"


@implementation Orders

@end

@implementation Passenger
- (void)book:(NSString *)name departure:(CLLocation *)departure destination:(CLLocation *)destination{
    self.unusedOrder.name = name;
    self.unusedOrder.departure = departure;
    self.unusedOrder.destination = destination;
        
}

- (BOOL)check:(Orders *)unusedOrder{
    if(self.unusedOrder.orderNumber == unusedOrder.orderNumber)
        return YES;
    else
        return NO;
}
@end
